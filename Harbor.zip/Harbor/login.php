<html>
    <body>
        <form action="Controller\loginController.php">
            <input type="text" name="username" value="" placeholder="Username"><br>
            <input type="password" name="password" value="" placeholder="Password"><br>
            <input type="submit" value="Submit">
        </form>
    </body>
</html>